# Birthday Website ❤️

Ready for GitHub Pages.

1. Create a GitHub repository.
2. Upload `index.html` to the repository root.
3. Go to Settings → Pages.
4. Choose Deploy from a branch.
5. Select `main` and `/(root)`, then Save.
6. GitHub will show your website URL.

The photos are embedded in `index.html`, so no separate image files are needed.
